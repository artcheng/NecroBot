﻿namespace PoGo.NecroBot.Logic.Event
{
    public class UseBerryEvent : IEvent
    {
        public int Count;
    }
}