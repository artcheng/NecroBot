﻿using System;

namespace PokemonGo.RocketAPI.Exceptions
{
    public class AccessTokenExpiredException : Exception
    {
    }
}